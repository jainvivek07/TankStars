<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tiled" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="7056" columns="112">
 <image source="../../TankStarsNew22/assets/hill.jpg" width="1920" height="1080"/>
</tileset>