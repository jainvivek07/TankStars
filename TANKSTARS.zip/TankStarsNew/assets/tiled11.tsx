<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tileset_gutter" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="986" columns="34">
 <image source="tileset_gutter.png" width="594" height="504"/>
</tileset>
